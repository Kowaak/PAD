﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Napoje24.Form1;

namespace Napoje24
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public class Napoj
        {
            public string Nazwa { get; set; }
            public string Producent { get; set; }
            public decimal Cena { get; set; }
            public int objetosc { get; set; }
            public string NazwaPlikuObrazka { get; set; }
            public DateTime DataWaznosci { get; set; }
        }

        private List<Napoj> napoje = new List<Napoj>();
        public int aktualnyIndeks = 0;
        private string katalogObrazkow = @"C:\Users\4m\Downloads\dane\napoje\";
        private List<Napoj> napojeFiltr = new List<Napoj>();
        private Random los = new Random();

        private void btnWczytaj_Click(object sender, EventArgs e)
        {
            string[] linie = File.ReadAllLines(@"C:\Users\4m\Downloads\dane\dane.txt");
            napoje.Clear();

            for (int i = 0; i + 5 < linie.Length; i += 6)
            {
                Napoj napoj = new Napoj
                {
                    Nazwa = linie[i],
                    Producent = linie[i + 1],
                    Cena = decimal.Parse(linie[i + 2]),
                    objetosc = int.Parse(linie[i + 3]),
                    DataWaznosci = DateTime.Parse(linie[i + 4]),
                    NazwaPlikuObrazka = linie[i + 5]
                };
                napoje.Add(napoj);
            }

            if (napoje.Count > 0)
            {
                aktualnyIndeks = 0;
                wyswietl(napoje[aktualnyIndeks]);
            }
        }

        private void btnLosuj_Click(object sender, EventArgs e)
        {
            if (napoje.Count > 0)
            {
                aktualnyIndeks = los.Next(napoje.Count);
                wyswietl(napoje[aktualnyIndeks]);
            }
        }

        private void btnWstecz_Click(object sender, EventArgs e)
        {
            if (JestFiltrowane())
            {
                if (aktualnyIndeks > 0)
                {
                    aktualnyIndeks--;
                    wyswietl(napojeFiltr[aktualnyIndeks]);
                }
            }
            else
            {
                if (aktualnyIndeks > 0)
                {
                    aktualnyIndeks--;
                    wyswietl(napoje[aktualnyIndeks]);
                }
            }
        }
        private void btnDalej_Click(object sender, EventArgs e)
        {
            if (JestFiltrowane())
            {
                if (aktualnyIndeks < napojeFiltr.Count - 1)
                {
                    aktualnyIndeks++;
                    wyswietl(napojeFiltr[aktualnyIndeks]);
                }
            }
            else
            {
                if (aktualnyIndeks < napoje.Count - 1)
                {
                    aktualnyIndeks++;
                    wyswietl(napoje[aktualnyIndeks]);
                }
            }
        }
        private void wyswietl(Napoj n)
        {
            txtNazwa.Text = n.Nazwa;
            txtProducent.Text = n.Producent;
            txtCena.Text = n.Cena.ToString("0.00");
            txtObje.Text = n.objetosc.ToString();
            txtData.Text = n.DataWaznosci.ToShortDateString();
            groupBox1.Text = $"Napój {aktualnyIndeks + 1} z {(JestFiltrowane() ? napojeFiltr.Count : napoje.Count)}";

            string path = Path.Combine(katalogObrazkow, n.NazwaPlikuObrazka);
            if (File.Exists(path))
            {
                pictureBox1.Image = Image.FromFile(path);
            }
        }
        private bool JestFiltrowane()
        {
            return napojeFiltr.Count > 0;
        }
        private void FiltrujNapoje()
        {
            napojeFiltr = napoje.Where(n => n.objetosc > 400).ToList();
            aktualnyIndeks = 0;
            if (napojeFiltr.Count > 0)
            {
                groupBox1.Text = $"Napój {aktualnyIndeks + 1} z {napojeFiltr.Count}";
                wyswietl(napojeFiltr[aktualnyIndeks]);
            }
            else
            {
                MessageBox.Show("Brak napojów powyżej 400 ml.");
                groupBox1.Text = "Brak napojów";
                pictureBox1.Image = null;
            }
        }

        private void btnFiltr_Click(object sender, EventArgs e)
        {
            FiltrujNapoje();
        }
    }
}
